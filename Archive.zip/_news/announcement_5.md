---
layout: post
date: 2022-07-01 15:59:00-0400
inline: true
---

In July, I participated in [EEML](assets/pdf/eeml2022.pdf) summer school, Swiss Equivariant Workshop and LOGML summer school. Over there, I gave poster presentations and participated in a project led by Gabriele Cesa on implicit kernels for steerable CNNs. Stay tuned for the results! 
