---
layout: post
date: 2022-07-10 15:59:00-0400
inline: true
---

Our [paper](/publications/) "Learning Generative Factors of EEG Data with Variational auto-encoders" was accepted to DGM4MICCAI 🎉 Happy to present the results in Singapur in September.
