---
layout: post
date: 2023-04-15 07:59:00-0400
inline: true
related_posts: false
---

Absolutely thrilled to announce that I will join the University of Amsterdam and start my PhD this spring, working with Max Welling, Jan-Willem van de Meent and Alfons Hoekstra!
