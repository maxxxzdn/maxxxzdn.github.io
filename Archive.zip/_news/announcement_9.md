---
layout: post
date: 2022-11-11 16:11:00-0400
inline: true
related_posts: false
---

Extremely proud to present the result of the LOGML research project I have been involved in for the last 3 months under the supervision of Gabriele Cesa. Equivariance for the win!
