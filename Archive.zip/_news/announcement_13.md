---
layout: post
date: 2024-05-23 07:59:00-0400
inline: true
related_posts: false
---

Clifford-Steerable CNNs was `accepted` to ICML 2024! See you all in Vienna!