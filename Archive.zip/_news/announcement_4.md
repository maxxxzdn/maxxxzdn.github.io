---
layout: post
date: 2022-06-04 15:59:00-0400
inline: true
---

Last week I attended [ML summer school](assets/pdf/mlss2022.pdf) in Krakow, where I presented our new paper on [generative modelling in neuroscience](assets/pdf/ccvae_poster.pdf).