---
layout: post
date: 2022-06-02 15:59:00-0400
inline: true
---

I participated in the Helmholtz AI conference and gave two poster presentations. One is about [generative modelling in neuroscience](assets/pdf/ccvae_poster.pdf), and the second is about [ML for GISAXS reconstruction](assets/pdf/gisaxs_poster.pdf).