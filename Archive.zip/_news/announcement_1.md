---
layout: post
date: 2022-03-31 15:59:00-0400
inline: true
---

I graduated from the Faculty of Computer Science of TU Dresden. See my thesis [here](assets/pdf/msc_thesis.pdf).