---
layout: post
date: 2022-08-22 15:59:00-0400
inline: true
related_posts: false
---

Recently, I participated at ICPR 2022, where I presented the paper "Investigating Brain Connectivity with Graph Neural Networks and GNNExplainer". The GitHub repo is available, and the recording will be released soon too.
