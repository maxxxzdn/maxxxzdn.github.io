---
layout: post
date: 2022-05-18 15:59:00-0400
inline: true
---

I will be presenting the [paper](/publications/) "Investigating Brain Connectivity with Graph Neural Networks and GNNExplainer" at ICPR 2022.