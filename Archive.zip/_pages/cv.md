---
layout: cv
permalink: assets/pdf/cv.pdf
title: curriculum vitae
nav: false
nav_order: 3
cv_pdf: cv.pdf
---
